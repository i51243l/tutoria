<?php
/*$servidor="localhost";
$usuario="silvacayu";
$password="riesgos";
$bd="riesgos";

$conexion= new mysqli($servidor,$usuario,$password,$bd);*/
	$servidor="pck591";
	$usuario="usr_gesiex";
	$password="pwdgesiex";
	$bd="gesiex";
	$conexion= new mysqli($servidor,$usuario,$password,$bd);

?>
