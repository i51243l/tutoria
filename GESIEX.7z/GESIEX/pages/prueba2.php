<!DOCTYPE html>
<html lang="en">
<head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

   <title>Gestión de la Información Externa</title>
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <script language='javascript'>
      function valida_envia(){ 
      alert('Muchas gracias por enviar el formulario'); 
      document.prueba2.submit(); 
      } 
    </script>



</head>


<?php 
  include_once("conexion.php"); 
    error_reporting(E_ALL ^ E_NOTICE);

     /* if (isset($_POST["nombre"], $_POST["edad"])){
          $nombre=$_POST['nombre'];
          $edad=$_POST['edad'];
   
        } */

      $nombre=$_POST['nombre'];
   
      $edad=$_POST['edad']; 
          

      if (empty($nombre))
      {
       $nombre=NULL;
    
     } 
   if (empty($edad))
   {
        $edad=0;
     } 
      
      $query = "INSERT INTO prueba VALUES (NULL, '".$nombre."', '".$edad."')";
       $result=$conexion->query($query); 
      /*if($result)
      
        echo "<br>";
        echo "<center>La peticion se realizo con exito</center>";
        echo "<br>";
        echo "<center><a href=\"prueba2.php\">Retornar</a></center>"; */

        
?>

<body>
  <div id="wrapper">
    <div id="page-wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h2 class="page-header">Registro de Noticia</h2>
          </div>
        </div>   
        <form role="form" method="POST" action="prueba2.php" id="prueba2" name="prueba2" >
      
              <div class="row">
                            <div class="col-md-3">
                              <div class="form-group">
                                <label>id</label>
                                <input id="id" name="id" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-3"> 
                              <div class="form-group">
                                <label>nombre</label>
                                <input id="nombre" name="nombre" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>
                            <div class="col-md-3"> 
                              <div class="form-group">
                                <label>edad</label>
                                <input id="edad" name="edad" class="form-control">
                                <p class="help-block"></p>
                              </div>
                            </div>

                          </div>
                          <br> <br>
                          <button type="submit" class="btn btn-info btn-md">Agregar</button>  
                               <input name="Enviar" class="btn btn-info btn-md" type="button" id="Enviar" value="Guardar" onClick="valida_envia()"/> 
              </div>
       
        </form>
        <br>
    </div>   
  </div>
  <script src="../bower_components/jquery/dist/jquery.min.js"></script>
  <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>
  <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
