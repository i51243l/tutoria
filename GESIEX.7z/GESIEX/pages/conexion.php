<?php
function conectarse(){
	$servidor="pck591";
	$usuario="usr_gesiex";
	$password="pwdgesiex";
	$bd="gesiex";
	$conectar= new mysqli($servidor,$usuario,$password,$bd);
	return $conectar;
}
$conexion=conectarse();
?>